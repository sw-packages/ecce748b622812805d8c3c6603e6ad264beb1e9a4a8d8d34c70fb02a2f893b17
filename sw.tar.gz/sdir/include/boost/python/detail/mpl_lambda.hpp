// Copyright David Abrahams 2002.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef MPL_LAMBDA_DWA2002122_HPP
# define MPL_LAMBDA_DWA2002122_HPP

// this header should go away soon
# include <boost/mpl/aux_/lambda_support.hpp>
# define BOOST_PYTHON_MPL_LAMBDA_SUPPORT BOOST_MPL_AUX_LAMBDA_SUPPORT

#endif // MPL_LAMBDA_DWA2002122_HPP
